import java.util.ArrayList;


public class StringOccurenceFinder {

	public int[] preProcessPattern(String ptrn) {
		//Thank you KMP algorithm for saving me
	    int i = 0, j = -1;
	    int ptrnLen = ptrn.length();
	    int[] preProcessTable = new int[ptrnLen + 1];
	 
	    preProcessTable[i] = j;
	    while (i < ptrnLen) {            
	            while (j >= 0 && ptrn.charAt(i) !=  ptrn.charAt(j)) {
	            // if there is mismatch consider the next widest border
	            // The borders to be examined are obtained in decreasing order from 
	            //  the values b[i], b[b[i]] etc.
	            j = preProcessTable[j];
	        }
	        i++;
	        j++;
	        preProcessTable[i] = j;
	    }
	    return preProcessTable;
	}
	
	public ArrayList<Integer> searchSubString(String text, String ptrn) {
        int i = 0, j = 0;
        // pattern and text lengths
        int ptrnLen = ptrn.length();
        int txtLen = text.length();
        ArrayList<Integer> occurrenceFoundList=new ArrayList<Integer>();
        // initialize new array and preprocess the pattern
        int[] b = preProcessPattern(ptrn);
 
        while (i < txtLen) {
            while (j >= 0 && text.charAt(i) != ptrn.charAt(j)) {
                j = b[j];
            }
            i++;
            j++;
 
            // a match is found
            if (j == ptrnLen) {
               // System.out.println("found substring at index:" + (i - ptrnLen));
                occurrenceFoundList.add(i-ptrnLen);
                j = b[j];
            }
        }
        return occurrenceFoundList;
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
