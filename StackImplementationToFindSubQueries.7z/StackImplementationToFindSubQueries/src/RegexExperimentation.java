
public class RegexExperimentation {

	
	
	public static void main(String [] args){
		
		
		
		
	}
}
