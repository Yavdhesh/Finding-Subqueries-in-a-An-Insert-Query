import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import java.util.Stack;


public class AlgorithmToFindSubQueries {
	
	/*public static void queryHashReplacer(StringOccurenceFinder sf,String query,String duplicateQuery,ArrayList<StackDTO> stackDTOList,Stack<String> hashStack,ArrayList<String> hashList,HashMap<String, String> hashAndSubQueryMap ){
		
		if(sf.searchSubString(duplicateQuery, "select").size()>=1){
		for (int j = 0; j < stackDTOList.size(); j++) {
			//System.out.println(stackDTOList.get(j).getOpeningIndex()+" and "+stackDTOList.get(j).getClosingIndex());
			String substring=query.substring(stackDTOList.get(j).getOpeningIndex(), stackDTOList.get(j).getClosingIndex()+1);
		
		if(sf.searchSubString(substring,"select").size()==1){
			System.out.println(substring);
		
			hashList.add("1$~#"+j);
			hashAndSubQueryMap.put("1$~#"+j, substring);
			hashStack.push("1$~#"+j);
			
			duplicateQuery=duplicateQuery.replace(substring, "1$~#"+j);
			
			
			
		}	
		}
		queryHashReplacer(StringOccurenceFinder sf,query,duplicateQuery,stackDTOList,hashStack,hashList,hashAndSubQueryMap )
		}
		
	}*/
	
	
	public static String subQueryHandlingAlgorithm(/*String query,*/HashMap<String, String> hashAndSubQueryMap,ArrayList<String> hashList,Stack<String> replacementOrderStack){
		String query="insert into bcp_rmr_asso_tagging (select seq_asso_taggin.nextval, (select role_classify_id from bcp_role_classification where role_id = 814 and tagged_by_id = ? and bcp_type_id = ?),?, (select person_id from emp_hr_basic_details where employee_number = ?), ? , sysdate,null,null,1,null,0,?,null,null,null where (select (count(1)) from bcp_rmr_asso_tagging where role_classify_id =(select role_classify_id from bcp_role_classification where role_id = 814 and bcp_type_id = ?) and person_id = (select person_id from emp_hr_basic_details where employee_number = ?) ) = 0)";
		String duplicateQuery=new String(query);
		Stack<StackDTO> charStack=new Stack<StackDTO>();
		String yetAnotherQuery=query;
		Random rand=new Random();
		
		
		StringOccurenceFinder sf=new StringOccurenceFinder();  //find all the occurrence of a String
		/*HashMap<String, String> hashAndSubQueryMap=new HashMap<String, String>();
		ArrayList<String> hashList=new ArrayList<String>();
		Stack<String> replacementOrderStack=new Stack<String>();*/
		 //Assuming the query is a balanced expression it terms of parenthesis
		while(sf.searchSubString(duplicateQuery, "select").size()!=0){
			ArrayList<StackDTO> stackDTOList=new ArrayList<StackDTO>();
			int i=0;
		while(i<query.length()){
			
			if(query.charAt(i)=='('){
				StackDTO stackdto=new StackDTO();
				stackdto.setOpeningIndex(i);
				charStack.push(stackdto);
				//System.out.println("While adding to stack"+stackdto);
			}
			
			if(query.charAt(i)==')'){
				StackDTO stack=charStack.pop();
				stack.setClosingIndex(i);
				stackDTOList.add(stack);
				//System.out.println("While removing from stack"+stackdto);
			}
			
			i++;
		}
		
		//System.out.println(stackDTOList.size());
		
		for (int j = 0; j < stackDTOList.size(); j++) {
			//System.out.println(stackDTOList.get(j).getOpeningIndex()+" and "+stackDTOList.get(j).getClosingIndex());
			String substring=query.substring(stackDTOList.get(j).getOpeningIndex(), stackDTOList.get(j).getClosingIndex()+1);
		
		if(sf.searchSubString(substring,"select").size()==1){
		//	System.out.println(substring);
		    Integer randomValue=rand.nextInt();
			hashList.add("1$~#"+randomValue);
			hashAndSubQueryMap.put("1$~#"+randomValue, substring);
			replacementOrderStack.push("1$~#"+randomValue);
			
			
			duplicateQuery=duplicateQuery.replace(substring, "1$~#"+randomValue);
			System.out.println("Thank you stack for saving me");
			
			
			
		}
		}
		
	   query=duplicateQuery;
			
		}
		
		return query;
	} 
	
	
	
	

	public static void main(String[] args) {
		String query="insert into bcp_rmr_asso_tagging (select seq_asso_taggin.nextval, (select role_classify_id from bcp_role_classification where role_id = 814 and tagged_by_id = ? and bcp_type_id = ?),?, (select person_id from emp_hr_basic_details where employee_number = ?), ? , sysdate,null,null,1,null,0,?,null,null,null where (select (count(1)) from bcp_rmr_asso_tagging where role_classify_id =(select role_classify_id from bcp_role_classification where role_id = 814 and bcp_type_id = ?) and person_id = (select person_id from emp_hr_basic_details where employee_number = ?) ) = 0)";
		String duplicateQuery=new String(query);
		Stack<StackDTO> charStack=new Stack<StackDTO>();
		int i=0;
		ArrayList<StackDTO> stackDTOList=new ArrayList<StackDTO>();
		StringOccurenceFinder sf=new StringOccurenceFinder();  //find all the occurrence of a String
		HashMap<String, String> hashAndSubQueryMap=new HashMap<String, String>();
		ArrayList<String> hashList=new ArrayList<String>();
		Stack<String> replacementOrderStack=new Stack<String>();
		 //Assuming the query is a balanced expression it terms of parenthesis
		while(i<query.length()){
			
			
			if(query.charAt(i)=='('){
				StackDTO stackdto=new StackDTO();
				stackdto.setOpeningIndex(i);
				charStack.push(stackdto);
				//System.out.println("While adding to stack"+stackdto);
			}
			
			if(query.charAt(i)==')'){
				StackDTO stack=charStack.pop();
				stack.setClosingIndex(i);
				stackDTOList.add(stack);
				//System.out.println("While removing from stack"+stackdto);
			}
			
			i++;
		}
		
		//System.out.println(stackDTOList.size());
		
		for (int j = 0; j < stackDTOList.size(); j++) {
			//System.out.println(stackDTOList.get(j).getOpeningIndex()+" and "+stackDTOList.get(j).getClosingIndex());
			String substring=query.substring(stackDTOList.get(j).getOpeningIndex(), stackDTOList.get(j).getClosingIndex()+1);
		
		if(sf.searchSubString(substring,"select").size()==1){
		//	System.out.println(substring);
		
			hashList.add("1$~#"+j);
			hashAndSubQueryMap.put("1$~#"+j, substring);
			
			
			duplicateQuery=duplicateQuery.replace(substring, "1$~#"+j);
			
			
			
			
		}
		}
		
		//System.out.println(duplicateQuery);

		
		HashMap<String, String> hashAndSubQueryMap1=new HashMap<String, String>();
		ArrayList<String> hashList1=new ArrayList<String>();
		Stack<String> replacementOrderStack1=new Stack<String>();
		System.out.println(subQueryHandlingAlgorithm(/*String query,*/hashAndSubQueryMap1,hashList1,replacementOrderStack1));
		//System.out.println(hashAndSubQueryMap1);
		
		//System.out.println(query);
		/*for (Iterator iterator = replacementOrderStack1.iterator(); iterator
				.hasNext();) {
			String string = (String) iterator.next();
			//System.out.println(hashAndSubQueryMap1.get(string));
			
		}
		*/
		
		System.out.println(replacementOrderStack1.size());
		String first=replacementOrderStack1.pop();
		System.out.println("first key"+first+"and value is"+hashAndSubQueryMap1.get(first));
		String second=replacementOrderStack1.pop();
		System.out.println("second key"+second+"and value is"+hashAndSubQueryMap1.get(second));
		String third=replacementOrderStack1.pop();
		System.out.println("third key"+third+"and value is"+hashAndSubQueryMap1.get(third));
		String fourth=replacementOrderStack1.pop();
		System.out.println("fourth key"+fourth+"and value is"+hashAndSubQueryMap1.get(fourth));
		String fifth=replacementOrderStack1.pop();
		System.out.println("five key"+fifth+"and value is"+hashAndSubQueryMap1.get(fifth));
		String six=replacementOrderStack1.pop();
		System.out.println("six key"+six+"and value is"+hashAndSubQueryMap1.get(six));
	}
  
	
}
