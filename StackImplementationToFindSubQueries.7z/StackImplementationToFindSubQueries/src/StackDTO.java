
public class StackDTO {
	
	private int openingIndex;
	private int closingIndex;
	
	public int getOpeningIndex() {
		return openingIndex;
	}
	public void setOpeningIndex(int openingIndex) {
		this.openingIndex = openingIndex;
	}
	public int getClosingIndex() {
		return closingIndex;
	}
	public void setClosingIndex(int closingIndex) {
		this.closingIndex = closingIndex;
	}
	
    public String toString(){
    	
    	StringBuilder strb=new StringBuilder();
    	strb.append("This subquery Begins At : ");
    	strb.append(getOpeningIndex()+" ");
    	strb.append("This subquery Ends At : ");
    	strb.append(getClosingIndex()+" ");
		return strb.toString();
    	
    }
}
